import os
import requests
from slack_bolt import App
from slack_bolt.adapter.aws_lambda import SlackRequestHandler
from dotenv import load_dotenv
from langdetect import detect

load_dotenv()

FLAG_LANG_MAP = {
    'jp': 'JA',
    'kr': 'KO',
    'cn': 'ZH',
    'us': 'EN'
}

glossary_list = []

# Initialize the Slack App without the `ignore_signature_verification` parameter.
app = App(
    token=os.getenv("SLACK_BOT_TOKEN"),
    signing_secret=os.getenv("SLACK_SIGNING_SECRET"),
    process_before_response=True
)

# Initialize the SlackRequestHandler with the `ignore_signature_verification` parameter.
handler = SlackRequestHandler(app)

def get_all_glossaries():
    try:
        headers = {
            'Authorization': f'DeepL-Auth-Key {os.getenv("DEEPL_API_KEY")}'
        }
        response = requests.get('https://api-free.deepl.com/v3/glossaries', headers=headers)
        return response.json().get("glossaries", [])
    except Exception as e:
        print(f"Error fetching glossaries: {e}")
        return []

def translate_text(text, source_lang=None, target_lang="EN"):
    url = "https://api-free.deepl.com/v2/translate"
    params = {
        "auth_key": os.getenv("DEEPL_API_KEY"),
        "text": text,
        "target_lang": target_lang
    }
    if source_lang:
        params["source_lang"] = source_lang
    if glossary_list:
        params["glossary_id"] = glossary_list[0]["glossary_id"]

    print("translate params", params)

    res = requests.post(url, params=params)

    print(res)

    data = res.json()["translations"][0]
    return {
        "translated_text": data["text"],
        "detected_source_lang": data.get("detected_source_language")
    }

@app.event("reaction_added")
def handle_reaction_added(body, client, event):
    print("event: ", event)
    # This line has been updated for better compatibility
    target_lang = FLAG_LANG_MAP.get(event["reaction"])
    if not target_lang:
        print("Error - Target lang not found")
        return
    
    print("target_lang", target_lang)

    channel_id = event["item"]["channel"]
    message_ts = event["item"]["ts"]

    print(channel_id, message_ts)

    try:
        result = client.conversations_history(
            channel=channel_id,
            latest=message_ts,
            inclusive=True,
            limit=1
        )
        
    except Exception as e:
        print(f"Error fetching message history: {e}")
        return


    print("result:", result)

    original_text = result["messages"][0].get("text", "")
    if not original_text.strip():
        print("Something wrong here")
        return
    
    print("Translating ", original_text)

    try:
        detected_lang = detect(original_text).upper()
        print("detected_lang", detected_lang)

        if detected_lang == target_lang:
            return
        
    except Exception as e:
        print(f"Error fetching message history: {e}")
        return
    
    print("target_lanng", target_lang)

    result = translate_text(original_text, source_lang=detected_lang, target_lang=target_lang)

    print("translated result", result)

    client.chat_postMessage(
        channel=channel_id,
        thread_ts=message_ts,
        text=f"🌐 *Translated ({target_lang}):*\n{result['translated_text']}"
    )

def lambda_handler(event, context):
    print("Lambda triggered with event:", event)
    global glossary_list
    if not glossary_list:
        glossary_list = get_all_glossaries()
    return handler.handle(event, context)